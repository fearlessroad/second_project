<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = "users";
$route['404_override'] = 'users';
$route['register']='users/register/';
$route['login']='users/login/';
$route['welcome/(:num)']='users/welcome/$1';
$route['logoff/(:num)']='users/logoff/$1';


/* End of file routes.php */
/* Location: ./application/config/routes.php */